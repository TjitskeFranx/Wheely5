function resetAll(){ //reset is apperently some keyword?
  BlueTiles=0;
  RedTiles=0;
  NeutralTiles=TilesAmount;
  update();
  Time=90;
}
